pub fn passed(score: u32) -> bool {
    score >= 40
}

pub fn earned_distinction(score: u32) -> bool {
    score >= 75
}
