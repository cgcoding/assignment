pub fn build_summary(records: &[StudentRecord]) -> CourseSummary {
    summarize(records)
}

pub fn build_ranking(records: Vec<StudentRecord>) -> Vec<StudentRecord> {
    rank_records(records)
}
