pub fn load_records(input: &str) -> Vec<StudentRecord> {
    parse_records(input)
}
