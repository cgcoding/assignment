pub fn analyse(input: &str) -> CourseSummary {
    let records = load_records(input);
    build_summary(&records)
}

pub fn rankings(input: &str) -> Vec<StudentRecord> {
    let records = load_records(input);
    build_ranking(records)
}
